import random
import time

# Define the players' names
player_names = ["Yoshi", "Luigi", "Mario", "Wario", "Waluigi", "DK"]

# Define the initial state of the game
board_size = 20
star_position = random.randint(0, board_size - 1)
coins_per_player = 10
players = [{"name": name, "coins": coins_per_player, "position": 0} for name in player_names]

# Define the spaces on the board
spaces = [" "] * board_size
for i in range(board_size):
    if i == star_position:
        spaces[i] = "*"
    elif i % 5 == 0:
        spaces[i] = "R"
    elif i % 3 == 0:
        spaces[i] = "B"

# Define a function to roll the dice
def roll_dice():
    return random.randint(1, 10)

# Define a function to move a player
def move_player(player, spaces_to_move):
    player["position"] = (player["position"] + spaces_to_move) % board_size
    space_type = spaces[player["position"]]
    if space_type == "R":
        player["coins"] -= 3
    elif space_type == "B":
        player["coins"] += 3
    if player["position"] == star_position:
        player["coins"] -= 10

# Define a function to print the current state of the game
def print_game_state():
    print("-" * 40)
    for player in players:
        print(f"{player['name']}: {player['coins']} coins, position {player['position']}")
    print("Board: " + "".join(spaces))
    print("-" * 40)

# Play the game
while True:
    for player in players:
        print_game_state()
        print(f"{player['name']}'s turn")
        time.sleep(3)
        roll = roll_dice()
        print(f"{player['name']} rolled a {roll}")
        time.sleep(3)
        move_player(player, roll)
        if player["coins"] < 0:
            player["coins"] = 0
        if player["coins"] == 0:
            players.remove(player)
        if len(players) == 1:
            winner = players[0]["name"]
            print(f"{winner} wins!")
            exit()
